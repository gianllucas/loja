CREATE DATABASE loja_pecas;

CREATE TABLE `estoque` (
  `id` int(11) NOT NULL,
  `marca` varchar(40),
  `modelo` varchar(40),
  `descricao` varchar(50),
  `mod_fab` varchar(9),
  `cor` varchar(20),
  `valor` int(11) 	
);



INSERT INTO `estoque` (`id`, `marca`, `modelo`, `descricao`, `mod_fab`, `cor`, `valor`) VALUES
(1, 'honda', 'CG 125cc', 'corrente', '2009/2013', 'indefinida', 50),
(2, 'BMW', 'GS1250', 'Protetor de Carenagem', '2015/2015', 'branca', 1500),
(3, 'Volkswagen', 'Lander 250', 'capa de banco', '2000/2010', 'preto', 35),
(4, 'Mobil', 'Oleo Sintetico', '1l de oleo', '2001/2003', 'preto', 30),
(5, 'TRIUMPH', 'Tiger 800', 'lanterna', '2014/2014', 'super branca', 500),
(6, 'honda', 'bros 160', 'kit relação', '2009/2013', 'prata', 330);

ALTER TABLE `estoque`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `estoque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;
