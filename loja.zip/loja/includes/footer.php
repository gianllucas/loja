<!-- FAZ A RODAPE DA PAGINA -->

<footer class="page-footer azul-escuro">
    <!-- classe container para mantes os itens estaticos -->
    <div class="container">
        <div class="row center valign-wrapper">
            <div class="col 16 pull-l1 s12">
                <a href="index.php"><img width="300.20" src="assets/img.png" alt="LOGO GB oficial"></a>
                <p class="= white-text text-lighten-4">
                Copyright 2024 - GB Peças e Reparos
                </p>
            </div>
            <div class="col l6 push-l2 s12">
                <h5 class="white-text"> Menu</h5>
                <ul>
                    <li><a class="white-text" href="index.php">Home</a></li>
                    <li><a class="white-text" href="estoque.php">Estoque</a></li>
                    <li><a class="white-text" href="cadProduto.php">Cadastrar Produto</a></li>
                    <li><a class="white-text" href="relatorio.php">Relatórios</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script>
    M.AutoInit();
</script>
</body>
</html>
