<!DOCTYPE html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset= UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>GB PEÇAS E REPAROS</title>

    <!-- ESTIRILIZANDO A PAGINA COM CSS -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>

    <!-- CONECTANDO OS SCRIPTS -->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"> defer </script>
    <script src="js/materialize.js"> defer </script>
    <script src="js/init.js"> defer </script>
</head>
<body> 
    <!-- Faz a barra de navegaçao da pagina -->
    <nav class="white" role="navigation">
        <div class="nav-wrapper container"> <a id="logo-container" href="img.png"><img width="299.19" src="assets/img.png" alt="logo padroa gb motos e reparos">
            <ul class="right hide-on-med-and-down">
                <li><a href="index.php">Home</a></li>
                <li><a href="estoque.php">Estoque</a></li>
                <li><a href="cadProduto.php">Cadastrar</a></li>
                <li><a href="relatorio.php">Relatório</a></li>
            </ul>

            <ul id="nav-mobile" class="sidenav">
            <li><a href="index.php">Home</a></li>
            <li><a href="estoque.php">Estoque</a></li>
            <li><a href="cadProduto.php">Cadastrar</a></li>
            <li><a href="relatorio.php">Relatório</a></li>
            </ul>
            <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">Menu</i></a>
        </div>
    </nav>