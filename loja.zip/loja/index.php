<?php 
//incluindo o cabeçalho no index
    include_once 'includes/header.php';
?>

<div class="section no-pad-bot" id="index-banner">
    <!-- coloca o texto no centro da pagina -->
    <div class="container">
    <br><br>
        <div class="row center">
            <div class="col s12 m6 16 x 16">
                <h1 class="header center">
                    Controle Gerencial de Peças Automotivas
                </h1>
                <a href="estoque.php" id="download-button" class="btn-large waves-effect waves-light red">
                    Consultar Estoque
                </a>    
            </div>
                <div class="col s12 m6 16x 16">
                    <img src="assets/img.png" alt="logo GB motos e reparos">
                </div>
        </div>
        <br><br>
    </div>
</div>

<?php
//carrega  rodapé no index
include_once 'includes/footer.php';
?>